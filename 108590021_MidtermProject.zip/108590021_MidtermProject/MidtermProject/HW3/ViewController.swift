//
//  ViewController.swift
//  HW3
//
//  Created by 黃品宥 on 2022/3/21.
//

import UIKit
enum OperationType{
    case add
    case subtract
    case multiply
    case divide
    case none
}
var numberArray:[Int] = []
class ViewController: UIViewController {
    var emojiChoices = ["AC","+/-","%","/","7","8","9","*","4","5","6","-","1","2","3","+","0",".","="]
    var numberArray = [Double]()
    var arrayKey:Int = 1
    var operandArray = [String]()
    var operandKey = 1
    var combo = 0
    var combo1 = 0
    var dot:Bool = false
    func doubleToString(num: Double) -> String {
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 8
        formatter.numberStyle = .decimal
        
        return formatter.string(from: num as NSNumber) ?? "n/a"
    }
    func saveNumber(){
        numberArray.append(Double(answer.text!)!)
        answer.text = ""
        arrayKey += 1
        dot = false
    }
    func clearNumber(){
        var oldlong = long.text
        oldlong!.removeSubrange(oldlong!.index(oldlong!.endIndex, offsetBy:-answer.text!.count)..<oldlong!.index(oldlong!.endIndex, offsetBy: 0))
        print(oldlong!)
        answer.text = ""
        long.text = oldlong!
        clearbutton.setTitle("AC", for: .normal)
        if operandKey > 2 {
            if(operandArray[operandKey-2] == "+") {
                add()
                operandArray.removeLast()
                operandKey -= 1
            }
            else if (operandArray[operandKey-2] == "/") {
                divide()
                operandArray.removeLast()
                operandKey -= 1
            }
            else if (operandArray[operandKey-2] == "-") {
                subtract()
                operandArray.removeLast()
                operandKey -= 1
            }
            else if (operandArray[operandKey-2] == "*") {
                multiply()
                operandArray.removeLast()
                operandKey -= 1
            }
        }
    }
    func add(){
        operandArray.append("+")
        operandKey += 1
        buttoncollect[15].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        buttoncollect[3].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[7].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[11].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
    }
    func divide(){
        operandArray.append("/")
        operandKey += 1
        buttoncollect[3].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        buttoncollect[15].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[7].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[11].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
    }
    func subtract(){
        operandArray.append("-")
        operandKey += 1
        buttoncollect[11].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        buttoncollect[3].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[7].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[15].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
    }
    func multiply(){
        operandArray.append("*")
        operandKey += 1
        buttoncollect[7].backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        buttoncollect[3].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[15].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
        buttoncollect[11].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
    }
    func removeoperand(){
        operandArray.removeLast()
        operandKey -= 1
        var oldlong = long.text
        oldlong!.removeSubrange(oldlong!.index(oldlong!.endIndex, offsetBy:-1)..<oldlong!.index(oldlong!.endIndex, offsetBy: 0))
        print(oldlong!)
        long.text = oldlong!
    }
    func addzero(){
        if (long.text == ""){
            numberArray.append(Double(0))
            arrayKey += 1
            long.text = long.text! + "0"
        }
        else{
            if (answer.text == ""){
                removeoperand()
            }
            else{
                saveNumber()
            }
        }
    }
    func giveMeAnswer(){
        for i in 0...(operandArray.count-1){
            if (operandArray[i] == "*"){
                numberArray[i-combo] = numberArray[i-combo]*numberArray[i+1-combo]
                numberArray.remove(at: i+1-combo)
                combo += 1
            }
            else if (operandArray[i] == "/"){
                if numberArray[i+1-combo] == 0{
                    numberArray[i-combo] = 0
                }
                else{
                    numberArray[i-combo] = numberArray[i-combo]/numberArray[i+1-combo]
                }
                numberArray.remove(at: i+1-combo)
                combo += 1
            }
        }
        for i in 0...(operandArray.count-1){
            if (operandArray[i] == "+"){
                numberArray[0] = numberArray[0]+numberArray[1]
                numberArray.remove(at: 1)
            }
            else if (operandArray[i] == "-"){
                numberArray[0] = numberArray[0]-numberArray[1]
                numberArray.remove(at: 1)
            }
        }
        operandArray = []
        let formatter = NumberFormatter()
        formatter.minimumFractionDigits = 0
        formatter.string(for: numberArray[0])
        answer.text = doubleToString(num: numberArray[0])
        numberArray = []
        clearbutton.setTitle("AC", for: .normal)
        
    }
    
    @IBOutlet weak var long: UILabel!
    @IBOutlet weak var answer: UILabel!
    @IBOutlet weak var clearbutton: UIButton!
    

    
    @IBOutlet var buttoncollect: [UIButton]!
    
    @IBAction func eachButton(_ sender: UIButton) {
        if let cardNumber =
            buttoncollect.firstIndex(of:sender){
            print("cardNumber = \(String(describing: cardNumber))")
            if cardNumber != 0{
                if (cardNumber == 1){
                        answer.text = String(Double(answer.text!)! * -1)
                }
                else if (cardNumber == 2){
                    if answer.text != ""{
                        answer.text = String(Double(answer.text!)! * 0.01)
                    }
                }
                else if (cardNumber == 7){
                    addzero()
                    multiply()
                }
                else if (cardNumber == 3){
                    addzero()
                    divide()
                }
                else if (cardNumber == 11){
                    addzero()
                    subtract()
                }
                else if (cardNumber == 15){
                    addzero()
                    add()
                }
                else if (cardNumber == 18){
                    addzero()
                    giveMeAnswer()
                    combo = 0
                }
                else{
                    if cardNumber == 17{
                        if dot == false{
                            if (answer.text == ""){
                                answer.text = answer.text! + "0"
                                long.text = long.text! + "0"
                            }
                            answer.text = answer.text! + "\(emojiChoices[cardNumber])"
                            buttoncollect[15].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                            buttoncollect[3].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                            buttoncollect[7].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                            buttoncollect[11].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                        }
                    }
                    else{
                        answer.text = answer.text! + "\(emojiChoices[cardNumber])"
                        buttoncollect[15].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                        buttoncollect[3].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                        buttoncollect[7].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                        buttoncollect[11].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                    }
                    clearbutton.setTitle("C", for: .normal)
                }
                long.text = long.text! + "\(emojiChoices[cardNumber])"
                if cardNumber == 17{
                    if dot == true{
                        var oldlong = long.text
                        oldlong!.removeSubrange(oldlong!.index(oldlong!.endIndex, offsetBy:-1)..<oldlong!.index(oldlong!.endIndex, offsetBy: 0))
                        print(oldlong!)
                        long.text = oldlong!
                    }
                    dot = true
                }
            }
            else {
                if(clearbutton.title(for: .normal) == "C"){
                    clearNumber()
                    dot = false
                }
                else{
                    long.text = ""
                    answer.text = ""
                    numberArray = [Double]()
                    arrayKey = 1
                    operandArray = [String]()
                    operandKey = 1
                    combo = 0
                    clearbutton.setTitle("AC", for: .normal)
                    buttoncollect[15].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                    buttoncollect[3].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                    buttoncollect[7].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                    buttoncollect[11].backgroundColor = #colorLiteral(red: 0.9588497281, green: 0.6343992949, blue: 0.5113392472, alpha: 1)
                    dot = false
                }
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
